# Aussteiger Band-App – Version 8.3

GitHub-Pages-kompatible Offline-PWA mit Songbibliothek, mehreren Setlisten, Favoriten, lokalem Songeditor, Auto-Scroll, Akkordlexikon und barrierearmen Anzeigeeinstellungen.

## Veröffentlichung

Alle Dateien und Ordner aus diesem Verzeichnis direkt in das Stammverzeichnis des GitHub-Pages-Repositories hochladen. Nach dem Commit startet GitHub Actions das Deployment automatisch.

## Kontrolle nach dem Deployment

- Unter **Hinweise** steht „Version 8.3 – GitHub Pages“.
- Im **Aa-Menü** steht „Version 8.3“.
- Das Aa-Menü beginnt mit „🎸 Akkordfarbe ändern“.
- Der Dark Mode verwendet neutrales Schwarz und Grau ohne Brauntöne.

Bei einer installierten älteren PWA-Version die App vom Home-Bildschirm entfernen, alle offenen Tabs schließen und anschließend neu hinzufügen.


## Chordie-Recherche (Version 8.3)

Unter `research/chordie-links.html` stehen Suchlinks für alle Songs der Playlist Nadine und Martin. Aus rechtlichen Gründen enthält das Paket keine kopierten Liedtexte oder vollständigen Akkordblätter.


## Neu in Version 8.3

- Chordie-Suche direkt aus der App öffnen
- Nutzer-gesteuerter Import von Lyrics und Akkorden über die Zwischenablage
- Automatische Erkennung typischer Akkordzeilen und Umwandlung in die farbige Songblatt-Darstellung
- Speicherung ausschließlich lokal im Browser


## Neu in Version 8.3

- Chordie-Referenz pro Song speichern oder automatisch nach Titel und Interpret suchen
- Chordie-Schaltfläche direkt im Player
- Akkorde im Player in Halbtonschritten transponieren, ohne den Originaltext zu verändern
- App-Schriftgröße getrennt von der Lyrics-Schriftgröße einstellen
- Kompakteres Handy-Layout und nicht-sticky Schaltflächen im Aa-Menü
